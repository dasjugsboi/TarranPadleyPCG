﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        float mousePositionBlocks = (Input.mousePosition.y / Screen.width * 14);

        Vector3 p1Position = new Vector3(this.transform.position.x, 0.5f, 0);

        p1Position.y = Mathf.Clamp(mousePositionBlocks, -4f, 3f);

        this.transform.position = p1Position;
    }
}

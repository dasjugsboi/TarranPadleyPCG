﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ballscript : MonoBehaviour
{

    float randomX, randomY;
    int score1 = 0;
    int score2 = 0;
    int totalgoals = 0;
    public Text scoreText;
    public Text scoreText2;
    float forceValue = 4.5f;
    Rigidbody2D body;

    // Use this for initialization

    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        body.AddForce(new Vector2(forceValue * 70, 60));
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "rightgoalthing")
        {
            score1 = score1 += 1;
            scoreText.text = "Player 1 Score: " + score1.ToString();
            totalgoals = totalgoals += 1;
            if (totalgoals >= 2)
            {
                totalgoals = 0;
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            }
        }
        if (collision.gameObject.name == "leftgoalthing")
        {
            score2 = score2 += 1;
            scoreText2.text = "Player 2 Score: " + score2.ToString();
            totalgoals = totalgoals += 1;
            if (totalgoals >= 2)
            {
                totalgoals = 0;
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                
            }
        }

    }


    // Update is called once per frame
    void Update()
    {

    }
}

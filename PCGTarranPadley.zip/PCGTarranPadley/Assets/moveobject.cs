﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveobject : MonoBehaviour {
    public float period = 0.0f;
    float randomMove;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 position = this.transform.position;
        if (period > 1)
        {
            if (position.y > 0)
            {
                position.y--;
                position.y--;
                position.y--;
                this.transform.position = position;
                period = 0;
            }
            else
            {
                position.y++;
                position.y++;
                position.y++;
                this.transform.position = position;
                period = 0;
            }
        }
        period += UnityEngine.Time.deltaTime;
    }
}
